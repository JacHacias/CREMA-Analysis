Nuclear spin                         1.000000000000000D+00 au
Nuclear magnetic dipole moment       1.000000000000000D+00 n.m.
Nuclear electric quadrupole moment   1.000000000000000D+00 barns


 Interaction constants:

 Level1  J Parity         A (MHz)             B (MHz)             g_J

   1        4 +      2.9402851676D+01    3.8033867682D-01    1.3506927210D+00
   2        4 +      3.4487282434D+01    6.1163537668D-01    1.2504686348D+00
   3        4 +      3.6866581554D+02    6.3470418394D+00    1.2505008256D+00
   4        4 +      2.9422556579D+01    1.7849004825D-01    1.3506819266D+00
   5        4 +      3.4383879867D+01    2.7671409335D-01    1.2504784468D+00
