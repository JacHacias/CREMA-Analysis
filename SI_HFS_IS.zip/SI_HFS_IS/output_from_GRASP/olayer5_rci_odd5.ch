Nuclear spin                         1.000000000000000D+00 au
Nuclear magnetic dipole moment       1.000000000000000D+00 n.m.
Nuclear electric quadrupole moment   1.000000000000000D+00 barns


 Interaction constants:

 Level1  J Parity         A (MHz)             B (MHz)             g_J

   1        4 -      3.9857874901D+01    1.6799477732D+00    1.5010071748D+00
   2        4 -      4.2280608975D+01    8.0446406340D-01    1.5010085963D+00
   3        4 -      4.3109158589D+01    3.3784658049D-01    1.5010094785D+00
   4        4 -      4.3445400657D+01    9.8972602623D-02    1.5010101403D+00
