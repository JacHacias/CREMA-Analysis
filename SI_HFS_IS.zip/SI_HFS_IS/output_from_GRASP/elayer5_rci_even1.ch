Nuclear spin                         1.000000000000000D+00 au
Nuclear magnetic dipole moment       1.000000000000000D+00 n.m.
Nuclear electric quadrupole moment   1.000000000000000D+00 barns


 Interaction constants:

 Level1  J Parity         A (MHz)             B (MHz)             g_J

