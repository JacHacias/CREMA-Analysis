Nuclear spin                         1.000000000000000D+00 au
Nuclear magnetic dipole moment       1.000000000000000D+00 n.m.
Nuclear electric quadrupole moment   1.000000000000000D+00 barns


 Interaction constants:

 Level1  J Parity         A (MHz)             B (MHz)             g_J

   1        5 +      3.3305148552D+01    5.5014596800D-01    1.4008080240D+00
   2        5 +      3.3271157881D+01    2.1685405822D-01    1.4008084693D+00
